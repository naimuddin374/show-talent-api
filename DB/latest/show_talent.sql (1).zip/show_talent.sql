-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 12, 2020 at 08:36 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `show_talent`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1 COMMENT '1=Credit, 2=Debit',
  `amount` float(8,2) NOT NULL,
  `last_balance` float(8,2) NOT NULL,
  `available_balance` float(8,2) NOT NULL,
  `comment` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `user_id`, `type`, `amount`, `last_balance`, `available_balance`, `comment`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 100.00, 0.00, 100.00, 'This is the first account credit amount', 0, '2020-04-22 07:15:57', '2020-04-22 07:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approved,2=Reject',
  `category_id` int(11) NOT NULL DEFAULT 0,
  `placement` int(11) NOT NULL DEFAULT 1 COMMENT '1=Right side, 2=Middle content',
  `image` text DEFAULT NULL,
  `video` text DEFAULT NULL,
  `website` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `reject_note` text DEFAULT NULL,
  `reopen_note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `user_id`, `page_id`, `status`, `category_id`, `placement`, `image`, `video`, `website`, `start_date`, `end_date`, `reject_note`, `reopen_note`, `created_at`, `updated_at`, `admin_id`, `is_unread`, `points`) VALUES
(1, 5, 0, 1, 6, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:25:59', '2020-08-07 23:36:16', 0, 0, 0),
(2, 5, 0, 1, 7, 2, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:13', '2020-08-07 23:36:16', 0, 0, 0),
(3, 5, 0, 1, 6, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:04', '2020-08-07 23:36:16', 0, 0, 0),
(4, 5, 0, 1, 1, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:05', '2020-08-07 23:36:16', 0, 0, 0),
(5, 5, 0, 1, 7, 2, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:14', '2020-08-07 23:36:16', 0, 0, 0),
(6, 5, 0, 1, 7, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:07', '2020-08-07 23:36:16', 0, 0, 0),
(7, 5, 0, 1, 6, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:08', '2020-08-07 23:36:16', 0, 0, 0),
(8, 5, 0, 1, 4, 2, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:17', '2020-08-07 23:36:16', 0, 0, 0),
(9, 5, 0, 1, 1, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:09', '2020-08-07 23:36:16', 0, 0, 0),
(10, 5, 0, 1, 6, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:10', '2020-08-07 23:36:16', 0, 0, 0),
(11, 5, 0, 1, 4, 2, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:18', '2020-08-07 23:36:16', 0, 0, 0),
(12, 5, 0, 1, 1, 1, 'images/1590666917.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-10 06:26:11', '2020-08-07 23:36:16', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ad_audiences`
--

DROP TABLE IF EXISTS `ad_audiences`;
CREATE TABLE `ad_audiences` (
  `id` int(10) UNSIGNED NOT NULL,
  `ad_id` int(11) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `age_start` int(11) NOT NULL DEFAULT 0,
  `age_end` int(11) NOT NULL DEFAULT 0,
  `countries` text DEFAULT NULL,
  `cities` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad_audiences`
--

INSERT INTO `ad_audiences` (`id`, `ad_id`, `gender`, `age_start`, `age_end`, `countries`, `cities`, `created_at`, `updated_at`) VALUES
(1, 1, 'M', 18, 24, '1,2', '1,3', '2020-08-07 23:36:31', '2020-08-07 23:36:31');

-- --------------------------------------------------------

--
-- Table structure for table `ad_budgets`
--

DROP TABLE IF EXISTS `ad_budgets`;
CREATE TABLE `ad_budgets` (
  `id` int(10) UNSIGNED NOT NULL,
  `ad_id` int(11) NOT NULL,
  `amount` float(8,2) NOT NULL,
  `currency` varchar(20) NOT NULL DEFAULT 'BDT',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_budgets`
--

INSERT INTO `ad_budgets` (`id`, `ad_id`, `amount`, `currency`, `created_at`, `updated_at`) VALUES
(1, 12, 200.00, 'BDT', '2020-08-08 00:14:17', '2020-08-08 00:14:17');

-- --------------------------------------------------------

--
-- Table structure for table `audience_selects`
--

DROP TABLE IF EXISTS `audience_selects`;
CREATE TABLE `audience_selects` (
  `id` int(10) UNSIGNED NOT NULL,
  `ad_id` int(11) NOT NULL,
  `user_ids` text DEFAULT NULL,
  `age_start` int(11) NOT NULL DEFAULT 0,
  `age_end` int(11) NOT NULL DEFAULT 0,
  `country_ids` text DEFAULT NULL,
  `city_ids` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `bio` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name`, `bio`, `created_at`, `updated_at`) VALUES
(1, 'MD. FOYSAL', 'Life is race', '2020-04-20 13:08:10', '2020-04-20 13:08:10');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=Pending,1=Approve,2=Reject',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Society', 1, '2020-05-04 06:56:51', '2020-04-13 23:29:12'),
(4, 'Science & Technology', 1, '2020-05-04 06:56:59', '2020-04-19 05:55:20'),
(5, 'Business & Economy', 1, '2020-05-04 06:57:12', '2020-05-04 06:57:12'),
(6, 'Arts & Culture', 1, '2020-05-04 06:57:20', '2020-05-04 06:57:20'),
(7, 'Religion', 1, '2020-05-04 06:57:27', '2020-05-04 06:57:27'),
(8, 'Sports & Fitness', 1, '2020-05-04 06:57:37', '2020-05-04 06:57:37');

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE `chapters` (
  `id` int(10) UNSIGNED NOT NULL,
  `ebook_id` int(11) NOT NULL,
  `sequence` int(11) NOT NULL DEFAULT 1,
  `name` text CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `points` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `reopen_note` text DEFAULT NULL,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `ebook_id`, `sequence`, `name`, `description`, `status`, `points`, `reject_note`, `admin_id`, `reopen_note`, `is_unread`, `created_at`, `updated_at`) VALUES
(3, 3, 1, 'An electronic book', '<p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(32, 33, 34); font-family: sans-serif; font-size: 14px;\">An&nbsp;<b>electronic book</b>, also known as an&nbsp;<b>e-book</b>&nbsp;or&nbsp;<b>eBook</b>, is a&nbsp;<a href=\"https://en.wikipedia.org/wiki/Book\" title=\"Book\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">book</a>&nbsp;publication made available in&nbsp;<a href=\"https://en.wikipedia.org/wiki/Digital_data\" title=\"Digital data\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">digital</a>&nbsp;form, consisting of text, images, or both, readable on the&nbsp;<a href=\"https://en.wikipedia.org/wiki/Flat-panel_display\" title=\"Flat-panel display\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">flat-panel display</a>&nbsp;of computers or other electronic devices.<sup id=\"cite_ref-1\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-1\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[1]</a></sup>&nbsp;Although sometimes defined as \"an electronic version of a printed book\",<sup id=\"cite_ref-2\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-2\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[2]</a></sup>&nbsp;some e-books exist without a printed equivalent. E-books can be read on dedicated&nbsp;<a href=\"https://en.wikipedia.org/wiki/E-reader\" title=\"E-reader\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">e-reader</a>&nbsp;devices, but also on any computer device that features a controllable viewing screen, including&nbsp;<a href=\"https://en.wikipedia.org/wiki/Desktop_computer\" title=\"Desktop computer\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">desktop computers</a>,&nbsp;<a href=\"https://en.wikipedia.org/wiki/Laptop\" title=\"Laptop\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">laptops</a>,&nbsp;<a href=\"https://en.wikipedia.org/wiki/Tablet_computer\" title=\"Tablet computer\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">tablets</a>&nbsp;and&nbsp;<a href=\"https://en.wikipedia.org/wiki/Smartphone\" title=\"Smartphone\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">smartphones</a>.</p><p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(32, 33, 34); font-family: sans-serif; font-size: 14px;\">In the 2000s, there was a trend of print and e-book sales moving to the&nbsp;<a href=\"https://en.wikipedia.org/wiki/Internet\" title=\"Internet\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">Internet</a>,<sup class=\"noprint Inline-Template Template-Fact\" style=\"line-height: 1; font-size: 11.2px; white-space: nowrap;\">[<i><a href=\"https://en.wikipedia.org/wiki/Wikipedia:Citation_needed\" title=\"Wikipedia:Citation needed\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><span title=\"This claim needs references to reliable sources. (December 2017)\">citation needed</span></a></i>]</sup>&nbsp;where readers buy traditional paper books and e-books on&nbsp;<a href=\"https://en.wikipedia.org/wiki/Website\" title=\"Website\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">websites</a>&nbsp;using&nbsp;<a href=\"https://en.wikipedia.org/wiki/E-commerce\" title=\"E-commerce\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">e-commerce</a>&nbsp;systems. With print books, readers are increasingly browsing through&nbsp;<a href=\"https://en.wikipedia.org/wiki/Image\" title=\"Image\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">images</a>&nbsp;of the covers of books on publisher or bookstore websites and selecting and ordering titles online; the paper books are then delivered to the reader by mail or another delivery service. With e-books, users can browse through titles online, and then when they select and order titles, the e-book can be sent to them online or the user can download the e-book.<sup id=\"cite_ref-3\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-3\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[3]</a></sup>&nbsp;By the early 2010s, e-books had begun to overtake hardcover by overall publication figures in the U.S.<sup id=\"cite_ref-auto_4-0\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-auto-4\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[4]</a></sup></p><p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(32, 33, 34); font-family: sans-serif; font-size: 14px;\">The main reasons for people buying e-books are possibly lower prices, increased comfort (as they can buy from home or on the go with mobile devices) and a larger selection of titles.<sup id=\"cite_ref-5\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-5\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[5]</a></sup>&nbsp;With e-books, \"[e]lectronic&nbsp;<a href=\"https://en.wikipedia.org/wiki/Bookmark_(World_Wide_Web)\" class=\"mw-redirect\" title=\"Bookmark (World Wide Web)\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">bookmarks</a>&nbsp;make referencing easier, and e-book readers may allow the user to annotate pages.\"&nbsp;<sup id=\"cite_ref-pcmag.com_6-0\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-pcmag.com-6\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[6]</a></sup>&nbsp;\"Although fiction and non-fiction books come in e-book formats, technical material is especially suited for e-book delivery because it can be [electronically] searched\" for keywords. In addition, for programming books, code examples can be copied.<sup id=\"cite_ref-pcmag.com_6-1\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/E-book#cite_note-pcmag.com-6\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[6]</a></sup>&nbsp;The amount of e-book reading is increasing in the U.S.; by 2014, 28% of adults had read an e-book, compared to 23% in 2013. This is increasing, because by 2014 50% of American adults had an e-reader or a tablet, compared to 30% owning such devices in 2013</p>', 0, 0, NULL, 0, NULL, 0, '2020-06-18 06:44:09', '2020-06-18 06:44:09'),
(4, 5, 1, 'England looked all but beaten when they stumbled to 117-5 in their pursuit of a 277-run target set by Pakistan', '<p style=\"margin-bottom: var(--space2); line-height: 1.67;\">England looked all but beaten when they stumbled to 117-5 in their pursuit of a 277-run target set by Pakistan at Old Trafford but captain Joe Root felt confident about his team\'s battling qualities.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">\"We knew it would take something special but after last summer it is very hard to stop believing. It\'s a real strong trait of ours,\" he said.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">Almost a year on from Ben Stokes\' heroic batting display to stun Australia in the 2019 Ashes at Headingley, Jos Buttler and Chris Woakes combined to deliver a counter-attacking display in a 139-run sixth-wicket stand.</p>', 0, 0, NULL, 0, NULL, 0, '2020-08-09 05:51:00', '2020-08-09 05:51:00'),
(5, 5, 2, 'The middle-order pair targeted the Pakistan spinners with drives', '<p style=\"margin-bottom: var(--space2); line-height: 1.67;\">The middle-order pair targeted the Pakistan spinners with drives, sweeps and reverse-sweeps as visiting captain Azhar Ali lost his reviews in desperation.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">\"When Buttler and Woakes came in and played their shots, they put us under pressure and we couldn\'t really answer them,\" Ali said.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">\"So credit to them, they outplayed us in that period. Maybe we were too late to bring fielders up.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">\"It\'s disappointing but not over yet, there are still two tests to go.\"</p>', 0, 0, NULL, 0, NULL, 0, '2020-08-09 05:51:21', '2020-08-09 05:51:21');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=Pending,1=Approve,2=Reject',
  `country_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `status`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 'Dhaka', 1, 1, '2020-05-04 05:40:45', '2020-05-04 05:40:32'),
(2, 'Khulna', 1, 1, '2020-05-04 05:40:46', '2020-05-04 05:40:32'),
(3, 'New Work', 1, 2, '2020-05-04 05:41:29', '2020-05-04 05:41:29');

-- --------------------------------------------------------

--
-- Table structure for table `classifieds`
--

DROP TABLE IF EXISTS `classifieds`;
CREATE TABLE `classifieds` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL COMMENT '1=Product sale, 2=House Rent, 3=Other',
  `category_id` int(11) NOT NULL DEFAULT 0,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `city_id` int(11) NOT NULL DEFAULT 0,
  `title` text CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `image` text DEFAULT NULL,
  `price` float(8,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `reject_note` text DEFAULT NULL,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classifieds`
--

INSERT INTO `classifieds` (`id`, `user_id`, `page_id`, `type`, `category_id`, `contact`, `email`, `city_id`, `title`, `description`, `image`, `price`, `currency`, `address`, `status`, `reject_note`, `is_unread`, `admin_id`, `points`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 1, 5, '0155555555555', 'naim@gmail.com', 0, 'Title update from react 3 update test', '<p>Hello World</p>', 'images/classified/1591780140_thm_.jpeg', 1000.00, '1', 'Dhaka, BD', 0, NULL, 0, 0, 0, '2020-08-10 09:16:37', '2020-08-10 09:16:37'),
(2, 5, 0, 1, 8, '0155455444', 'admin@gmail.com', 0, '????????? ????, ???????? ?????? ??? ????', '<p>Test</p>', 'images/classified/1591781545_thm_.jpeg', 500.00, '1', NULL, 1, NULL, 0, 0, 0, '2020-08-08 12:35:02', '2020-06-10 03:32:25'),
(3, 3, 1, 2, 1, '0155455444', 'bhuiya@gmail.com', 0, 'Coronavirus Crisis A National Story Made Of Local Outbreaks', '<p><span style=\"color: rgb(36, 39, 41); font-family: Arial, &quot;Helvetica Neue&quot;, Helvetica, sans-serif; font-size: 13px;\">@thirtydot - You are right, with a lighter background, you can see it. But if your background is black you cannot see it at all. So I guess I shouldn\'t say it doesn\'t work. But it definitely is not visible without the spread when you have a black background, regardless of the color of the box-shadow. Even with red it appears your border is slightly red, but there is no \"visible\" box-shadow. So if you have a lighter background, then I guess this solution would work. For a very dark background, this solution is not reliable.</span><br></p>', 'images/classified/1591785384_thm_.jpeg', 600.00, '1', 'Dhaka, Bangladesh', 1, NULL, 1, 1, 33, '2020-08-05 06:12:44', '2020-08-05 00:12:44'),
(4, 5, 0, 1, 0, '0155555555555', 'naim@gmail.com', 0, 'Title update from react 3', '<p><br></p>', 'images/classified/1591883695_thm_.png', 500.00, '1', NULL, 1, NULL, 0, 1, 15, '2020-08-06 08:55:17', '2020-08-06 02:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `classified_galleries`
--

DROP TABLE IF EXISTS `classified_galleries`;
CREATE TABLE `classified_galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `classified_id` int(11) NOT NULL,
  `image` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classified_galleries`
--

INSERT INTO `classified_galleries` (`id`, `classified_id`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 'images/classified/15917801400.jpeg', '2020-06-10 03:09:00', '2020-06-10 03:09:00'),
(2, 1, 'images/classified/15917801401.jpeg', '2020-06-10 03:09:01', '2020-06-10 03:09:01'),
(3, 1, 'images/classified/15917801412.jpeg', '2020-06-10 03:09:02', '2020-06-10 03:09:02');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `comment_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `ebook_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Active,2=Reject',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `comment`, `comment_id`, `rating`, `reject_note`, `admin_id`, `is_unread`, `ebook_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'This is post comment', 0, 0, NULL, 0, 0, 0, 1, '2020-04-23 09:00:54', '2020-04-23 03:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
CREATE TABLE `comment_likes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `type` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=Pending,1=Approve,2=Reject',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Bangladesh', 1, '2020-05-04 05:40:05', '0000-00-00 00:00:00'),
(2, 'USA', 1, '2020-05-04 05:40:05', '0000-00-00 00:00:00'),
(3, 'India', 1, '2020-05-04 05:40:17', '0000-00-00 00:00:00'),
(4, 'UK', 1, '2020-05-04 05:40:17', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ebooks`
--

DROP TABLE IF EXISTS `ebooks`;
CREATE TABLE `ebooks` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `page_id` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) NOT NULL DEFAULT 0,
  `name` text CHARACTER SET utf8 DEFAULT NULL,
  `author_name` varchar(100) DEFAULT NULL,
  `publication_date` varchar(50) DEFAULT NULL,
  `preface` text CHARACTER SET utf8 DEFAULT NULL,
  `summary` text CHARACTER SET utf8 DEFAULT NULL,
  `author_summary` text CHARACTER SET utf8 DEFAULT NULL,
  `front_image` text DEFAULT NULL,
  `back_image` text DEFAULT NULL,
  `price` float(8,2) NOT NULL DEFAULT 0.00,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `reopen_note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ebooks`
--

INSERT INTO `ebooks` (`id`, `user_id`, `status`, `page_id`, `category_id`, `name`, `author_name`, `publication_date`, `preface`, `summary`, `author_summary`, `front_image`, `back_image`, `price`, `admin_id`, `is_unread`, `reject_note`, `points`, `reopen_note`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, 1, 'Test Book Title', 'English', '2020-04-25', 'Test ebook summery', 'Test author summery', '5', NULL, NULL, 200.00, 0, 0, NULL, 0, NULL, '2020-08-09 05:59:27', '2020-04-20 07:09:32'),
(2, 5, 1, 0, 4, 'Computer programming', 'programming is the process', '2020-06-25', 'Computer programming is the process of designing and building an executable computer program to accomplish a specific computing result.', 'Ebook Summary Computer programming is the process of designing and building an executable computer program to accomplish a specific computing result.', 'Author Summary Computer programming is the process of designing and building an executable computer program to accomplish a specific computing result.', NULL, NULL, 0.00, 0, 0, NULL, 0, NULL, '2020-08-09 05:59:29', '2020-06-18 05:43:10'),
(3, 5, 0, 0, 1, 'accomplish a specific', 'consumption', '2020-06-26', 'and the implementation of algorithms in a chosen programming language (commonly referred to as coding).[1][2] The source code of a program is written in one or more languages that are intelligible to programmers, rather than machine code, which is directly executed by the central processing unit. The purpose of programming is to find a sequence of instructions that will automate the performance of a task (which can be as complex as an operating system) on a computer, often for solving a given problem. Proficient programming thus often requires expertise in several different subjects, including knowledge of the application domain, specialized algorithms, and formal logic.', 'and the implementation of algorithms in a chosen programming language (commonly referred to as coding).[1][2] The source code of a program is written in one or more languages that are intelligible to programmers, rather than machine code, which is directly executed by the central processing unit. The purpose of programming is to find a sequence of instructions that will automate the performance of a task (which can be as complex as an operating system) on a computer, often for solving a given problem. Proficient programming thus often requires expertise in several different subjects, including knowledge of the application domain, specialized algorithms, and formal logic.', 'and the implementation of algorithms in a chosen programming language (commonly referred to as coding).[1][2] The source code of a program is written in one or more languages that are intelligible to programmers, rather than machine code, which is directly executed by the central processing unit. The purpose of programming is to find a sequence of instructions that will automate the performance of a task (which can be as complex as an operating system) on a computer, often for solving a given problem. Proficient programming thus often requires expertise in several different subjects, including knowledge of the application domain, specialized algorithms, and formal logic.', 'images/ebook/1592482896_front.jpeg', 'images/ebook/1592482896_back.jpeg', 0.00, 0, 0, NULL, 0, NULL, '2020-08-05 05:34:32', '2020-06-18 06:21:36'),
(5, 5, 1, 0, 8, 'Root hails England\'s mental strength after \'brilliant chase\'', 'Prothomalo', NULL, 'Almost a year on from Ben Stokes\' heroic batting display to stun Australia in the 2019 Ashes at Headingley, Jos Buttler and Chris Woakes combined to deliver a counter-attacking display in a 139-run sixth-wicket stand', 'Almost a year on from Ben Stokes\' heroic batting display to stun Australia in the 2019 Ashes at Headingley, Jos Buttler and Chris Woakes combined to deliver a counter-attacking display in a 139-run sixth-wicket stand', 'Almost a year on from Ben Stokes\' heroic batting display to stun Australia in the 2019 Ashes at Headingley, Jos Buttler and Chris Woakes combined to deliver a counter-attacking display in a 139-run sixth-wicket stand', NULL, NULL, 0.00, 0, 0, NULL, 0, NULL, '2020-08-09 06:32:04', '2020-08-09 06:31:47'),
(6, 5, 5, 0, 8, 'Essex decimate Surrey with Simon Harmer\'s eight', 'cricbuzz', NULL, 'Duanne Olivier and Jordan Thompson struck thrice each as Nottinghamshire were bundled out for 97 in their pursuit of 188 at Trent Bridge, on Tuesday (August 11) in their Bob Willis Trophy clash.', 'Duanne Olivier and Jordan Thompson struck thrice each as Nottinghamshire were bundled out for 97 in their pursuit of 188 at Trent Bridge, on Tuesday (August 11) in their Bob Willis Trophy clash.', 'Duanne Olivier and Jordan Thompson struck thrice each as Nottinghamshire were bundled out for 97 in their pursuit of 188 at Trent Bridge, on Tuesday (August 11) in their Bob Willis Trophy clash.', NULL, NULL, 0.00, 0, 0, NULL, 0, NULL, '2020-08-12 05:41:33', '2020-08-12 05:41:33');

-- --------------------------------------------------------

--
-- Table structure for table `ebook_likes`
--

DROP TABLE IF EXISTS `ebook_likes`;
CREATE TABLE `ebook_likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `ebook_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `edu_infos`
--

DROP TABLE IF EXISTS `edu_infos`;
CREATE TABLE `edu_infos` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `degree` varchar(100) DEFAULT NULL,
  `institute` varchar(150) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `passing_year` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Complete, 2=Continue, 3=Incomplete',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edu_infos`
--

INSERT INTO `edu_infos` (`id`, `user_id`, `degree`, `institute`, `start_date`, `end_date`, `passing_year`, `status`, `created_at`, `updated_at`) VALUES
(1, 5, 'BSEE', 'Green Univeristy', NULL, NULL, '2020', 1, '2020-05-02 23:49:53', '2020-05-16 07:18:57'),
(20, 5, 'SSC', 'Kalkini Pilot High School', NULL, NULL, '2013', 1, '2020-05-03 01:19:25', '2020-05-03 01:21:47'),
(21, 6, 'BSc. (Engg) CSE', 'Comilla University', NULL, NULL, '2019', 1, '2020-05-18 07:51:49', '2020-05-18 07:54:13'),
(22, 3, 'BSEE', 'Green Univeristy', NULL, NULL, '2020', 1, '2020-05-02 23:49:53', '2020-05-16 07:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

DROP TABLE IF EXISTS `followers`;
CREATE TABLE `followers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_page` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`id`, `profile_id`, `user_id`, `is_page`, `created_at`, `updated_at`) VALUES
(1, 5, 5, 0, '2020-05-20 12:14:01', '2020-05-20 12:14:01'),
(2, 6, 6, 0, '2020-05-23 16:32:31', '2020-05-23 16:32:31'),
(3, 5, 6, 0, '2020-05-23 18:13:09', '2020-05-23 18:13:09'),
(4, 3, 6, 0, '2020-05-23 18:13:47', '2020-05-23 18:13:47'),
(5, 1, 5, 1, '2020-06-02 00:55:10', '2020-06-02 00:55:10'),
(6, 3, 5, 0, '2020-08-06 03:06:04', '2020-08-06 03:06:04'),
(12, 7, 5, 1, '2020-08-09 07:32:00', '2020-08-09 07:32:00'),
(14, 6, 5, 0, '2020-08-10 06:03:12', '2020-08-10 06:03:12');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `creation_date` varchar(50) DEFAULT NULL,
  `expiration_date` varchar(50) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `view` int(11) NOT NULL DEFAULT 0,
  `follow` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `points` int(11) NOT NULL DEFAULT 0,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `user_id`, `category_id`, `name`, `email`, `contact`, `image`, `creation_date`, `expiration_date`, `bio`, `view`, `follow`, `status`, `points`, `admin_id`, `reject_note`, `is_unread`, `created_at`, `updated_at`) VALUES
(1, 5, 8, 'Tours and Travels', 'abc@gmail.com', '0155555555555', 'images/1591079465.png', NULL, NULL, 'Hello world', 0, 0, 1, 70, 0, NULL, 0, '2020-08-08 12:31:23', '2020-08-08 12:04:19'),
(2, 5, 8, 'Fahmid Hasan\'s Blog', 'fahmidhasananik@gmail.com', '01521441503', 'images/1589788672.jpeg', NULL, NULL, NULL, 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:24', '2020-05-18 07:57:52'),
(3, 5, 4, 'Tech Today', 'fahmidhasananik@gmail.com', '01647511395', 'images/1589788767.jpeg', NULL, NULL, NULL, 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:25', '2020-05-18 07:59:27'),
(4, 5, 8, 'Barca Fan Club', 'fahmidhasananik@gmail.com', '01547511395', 'images/1589800804.jpeg', NULL, NULL, 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum', 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:26', '2020-05-18 11:20:04'),
(5, 5, 5, 'IDEAS FOR DEVELOPMENT (IFD)', 'ideasfd@gmail.com', '0563725362', NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:29', '2020-05-18 11:52:42'),
(6, 5, 4, 'Tech Today', 'fahmidhasananik@gmail.com', '01647511395', 'images/1589788767.jpeg', NULL, NULL, NULL, 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:25', '2020-05-18 07:59:27'),
(7, 6, 8, 'Barca Fan Club', 'fahmidhasananik@gmail.com', '01547511395', 'images/1589800804.jpeg', NULL, NULL, 'lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum', 0, 0, 1, 0, 0, NULL, 0, '2020-08-09 07:26:55', '2020-05-18 11:20:04'),
(8, 5, 5, 'IDEAS FOR DEVELOPMENT (IFD)', 'ideasfd@gmail.com', '0563725362', NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, NULL, 0, '2020-08-08 12:31:29', '2020-05-18 11:52:42');

-- --------------------------------------------------------

--
-- Table structure for table `pdt_cats`
--

DROP TABLE IF EXISTS `pdt_cats`;
CREATE TABLE `pdt_cats` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `type` int(11) NOT NULL DEFAULT 0 COMMENT '1=Post, 2=News link, 3=Opinion, 4=Video, 5=Image, 6=Content post, 7=Other',
  `category_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL DEFAULT 0,
  `title` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `newslink` text DEFAULT NULL,
  `video` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `is_editor` int(11) NOT NULL DEFAULT 0,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `status`, `type`, `category_id`, `page_id`, `title`, `description`, `newslink`, `video`, `image`, `points`, `reject_note`, `admin_id`, `is_editor`, `is_unread`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 2, 1, 0, 'বিশাল এক আরাবিয়ান গ্রুপার মাছ বয়ে নিয়ে যাচ্ছে ইরাকি কিশোর', NULL, 'https://en.prothomalo.com/bangladesh/crime-and-law/police-quizzed-bullet-hit-sinha-claims-fir', NULL, NULL, 0, NULL, 0, 0, 0, '2020-08-08 12:42:55', '2020-05-28 01:24:37'),
(2, 5, 1, 2, 1, 0, 'করোনায় যুক্তরাষ্ট্রে মৃতের সংখ্যা এক লাখ ছাড়িয়েছে', NULL, 'https://en.prothomalo.com/bangladesh/crime-and-law/police-quizzed-bullet-hit-sinha-claims-fir', NULL, NULL, 0, NULL, 0, 0, 0, '2020-08-08 12:42:52', '2020-05-28 01:26:50'),
(3, 5, 1, 3, 1, 0, 'ভারতে পঙ্গপাল তাড়াতে ড্রোন', '<p><font face=\"Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif\"><span style=\"font-size: 18px; background-color: rgb(240, 240, 237);\"><br></span></font></p><p><font face=\"Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif\"><span style=\"background-color: rgb(240, 240, 237);\"><span style=\"font-size: 18px;\">পঙ্গপাল তাড়াতে ভারতের রাজস্থান রাজ্যে ড্রোন প্রযুক্তির ব্যবহার করা হয়েছে। আজ বৃহস্পতিবার টাইমস অব ইন্ডিয়ার প্রতিবেদনে জানানো হয়, এই প্রথম ভারতের কোনো রাজ্য পঙ্গপাল তাড়াতে ড্রোন প্রযুক্তি ব্যবহার করল।</span><br></span></font><br></p>', 'https://en.prothomalo.com/bangladesh/crime-and-law/police-quizzed-bullet-hit-sinha-claims-fir', NULL, NULL, 0, NULL, 0, 0, 0, '2020-08-08 12:42:57', '2020-05-28 01:27:35'),
(4, 3, 1, 3, 5, 0, 'বিশেষভাবে তৈরি এই ড্রোনগুলো ব্যবহার করে ১০ লিটার করে কীটনাশক ছড়ানো যায়', '<p>রাজ্য কৃষি বিভাগের কমিশনার ওম প্রকাশ বলেন, পঙ্গপাল ছড়িয়ে থাকা যেসব জায়গায় সাধারণ ট্র্যাক্টর পৌঁছানো সম্ভব ছিল না, সেখানে সফলভাবে ড্রোন দিয়ে পঙ্গপালদের চলাচল সাফ করে দেওয়া হয়েছে। মাঠ কর্মীদের এর প্রভাব সম্পর্কে একটি বিশদ মূল্যায়ন সরবরাহ করা হয়েছে।<br></p>', NULL, NULL, NULL, 0, NULL, 0, 0, 0, '2020-08-05 02:45:57', '2020-05-28 01:29:54'),
(5, 5, 1, 2, 6, 1, 'Three bodies recovered as boat capsizes in Kurigram', NULL, NULL, NULL, NULL, 0, NULL, 0, 0, 0, '2020-05-31 07:47:17', '2020-05-28 01:31:03'),
(7, 3, 1, 6, 1, 0, 'Coronavirus Crisis A National Story Made Of Local Outbreaks', NULL, NULL, 'r55lJPkVHf0', NULL, 0, NULL, 0, 0, 0, '2020-05-31 07:47:17', '2020-05-28 02:20:19'),
(8, 5, 0, 5, 1, 1, 'Lorem ipsum dolor sit amet', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor inc unt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cup atat non pro ent, sunt in culpa qui officia deserunt mollit', 'storage/images/1590666777.jpeg', 0, NULL, 0, 0, 0, '2020-05-31 07:47:17', '2020-05-28 05:52:57'),
(9, 5, 0, 5, 1, 1, 'Audio-based Image Distortion Effects', NULL, NULL, '', NULL, 0, NULL, 0, 0, 0, '2020-05-31 07:47:19', '2020-05-28 05:55:17'),
(11, 5, 0, 5, 8, 1, 'Test title from page', NULL, NULL, 'Hello World', NULL, 0, NULL, 0, 0, 0, '2020-05-31 02:20:27', '2020-05-31 02:20:27'),
(12, 5, 0, 5, 8, 1, 'আজ রোববার সকালে সরকারি বাসভবন থেকে সড়ক পরিবহন', NULL, NULL, '?? ?????? ????? ?????? ?????? ???? ??? ?????? ? ?????? ??????? ???????????? ????? ????? ????????? ? ??? ????? ??????? ?????? ??? ?????? ??????? ????, ?? ???????? ?????? ?????? ??????? ???????? ????? ????? ?????????? ????? ??? ????? ??????? ??????? ?????? ???? ??????? ??????? ????? ????, ????????? ?????????? ???? ??????? ???????? ??? ?????? ????????? (???????) ?????????? ???? ????? ?????????? ???? ??????????? ??? ???????? ?????? ????? ?????? ???? ?? ????? ???? ?????? ????? ??? ???? ????? ??????? ???? ????????? ??????? ????? ???, ????? ?????? ?????? ???????? ???? ????', NULL, 0, NULL, 0, 0, 0, '2020-05-31 02:23:44', '2020-05-31 02:23:44'),
(13, 5, 1, 5, 8, 1, 'Title update from react 3', '<p>সড়ক পরিবহন মন্ত্রী জানান, করোনাকালে বাস-মিনিবাস সমূহকে মোট আসনের অর্ধেক যাত্রী নিয়ে চলাচল করতে হবে। করোনা সংক্রমণ রোধে অর্ধেক আসন খালি থাকবে।</p><p>যানবাহনে যাত্রী, গাড়িচালক, সহকারী, কাউন্টারকর্মীসহ সবাইকে স্বাস্থ্য বিভাগের নির্দেশনা প্রতিপালন এবং মাস্ক পরিধানের অনুরোধ জানান আওয়ামী লীগের সাধারণ সম্পাদক।</p><p>ভিডিও কনফারেন্সে মন্ত্রী সড়ক বিভাগের এডিপি বাস্তবায়নে সন্তোষ প্রকাশ করেন। তিনি বলেন, প্রকল্পসমূহের চলমান কাজ দ্রুত বাস্তবায়ন করতে হবে।</p><p>সড়ক পরিবহন ও সেতুমন্ত্রী বলেন, উন্নয়ন একটি বহমান প্রক্রিয়া। উন্নয়ন থেমে গেলে জীবনও থেমে যাবে।</p>', NULL, '', NULL, 20, NULL, 5, 0, 1, '2020-08-08 12:04:19', '2020-08-08 12:04:19'),
(14, 5, 1, 5, 8, 1, 'Coronavirus Crisis A National Story Made Of Local Outbreaks update', '<p><span style=\"font-size: 18px; font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif;\">চীনের পর প্রথম যে কয়টা দেশের ওপর কোভিড-১৯ ব্যাপকভাবে হানা দিয়েছে, সেগুলোর একটা হলো দক্ষিণ কোরিয়া। তবে যুক্তরাষ্ট্র বা অনেক ইউরোপীয় দেশ যে ভুল করেছে, দক্ষিণ কোরিয়া তা করেনি। দক্ষিণ কোরিয়া প্রথম থেকেই কড়া নিয়ম মেনে এই মহামারি মোকাবিলা করেছে। তারা সারা দেশ লকডাউন না করেই ভাইরাসের সংক্রমণ দারুণভাবে কমিয়ে এনেছে। দেশটির এই পদক্ষেপগুলো অন্য দেশগুলো ও সুশীল সমাজের কাছে অনুসরণীয় হতে পারে।</span><br></p>', NULL, NULL, 'images/1590913912.jpeg', 10, NULL, 5, 0, 1, '2020-08-08 12:04:14', '2020-08-08 12:04:14'),
(15, 5, 1, 5, 8, 0, 'Title update from react 3 Update', '<p>Title update from react 3&nbsp;Title update from react 3&nbsp;Title update from react 3</p><p>Title update from react 3&nbsp;Title update from react 3</p><p>Title update from react 3 Update<br></p>', NULL, NULL, 'images/1591015342.jpeg', 10, NULL, 5, 0, 1, '2020-08-08 12:04:07', '2020-08-08 12:04:07'),
(16, 5, 1, 2, 8, 0, 'অনুশীলন নিয়ে বিসিবির অন্য চিন্তা', '<p><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">দেশে করোনার সংক্রমণের হার ঊর্ধ্বমুখী হওয়ার পরও খুলে গেছে সরকারি-বেসরকারি অফিস। তবে যতই সবকিছু চালু হোক, বাংলাদেশ ক্রিকেট বোর্ড (বিসিবি) এগোচ্ছে ধীরে চলো নীতিতে। অবশ্য খেলোয়াড়দের মাঠে কীভাবে ফেরানো যায়, সেটির প্রস্তুতি নিতে শুরু করেছে বোর্ড। শ্রীলঙ্কা এরই মধ্যে অনুশীলনে ফেরার পথে হাঁটছে। বিসিবি পর্যবেক্ষণ করবে তাদের কার্যক্রমও।</span><br></p>', NULL, '', NULL, 30, NULL, 5, 0, 1, '2020-08-08 12:02:59', '2020-08-08 12:02:59'),
(17, 5, 1, 5, 8, 0, 'Title update from react 3', NULL, NULL, '', 'images/1591078455.jpeg', 30, NULL, 5, 0, 1, '2020-08-08 12:03:56', '2020-08-08 12:03:56'),
(18, 5, 1, 5, 8, 0, 'ফুটবলাররা পণ্য, স্বীকারে আপত্তি নেই তাঁর', '<p><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">দেশে করোনার সংক্রমণের হার ঊর্ধ্বমুখী হওয়ার পরও খুলে গেছে সরকারি-বেসরকারি অফিস। তবে যতই সবকিছু চালু হোক, বাংলাদেশ ক্রিকেট বোর্ড (বিসিবি) এগোচ্ছে ধীরে চলো নীতিতে। অবশ্য খেলোয়াড়দের মাঠে কীভাবে ফেরানো যায়, সেটির প্রস্তুতি নিতে শুরু করেছে বোর্ড। শ্রীলঙ্কা এরই মধ্যে অনুশীলনে ফেরার পথে হাঁটছে। বিসিবি পর্যবেক্ষণ করবে তাদের কার্যক্রমও।</span><br></p>', NULL, '', 'images/1591078484.jpeg', 20, NULL, 5, 0, 1, '2020-08-08 12:03:49', '2020-08-08 12:03:49'),
(19, 5, 1, 3, 8, 0, 'তবে ক্রিকেটারদের এখনই কোভিড-১৯ পরীক্ষা করাবে না বিসিবি', '<p><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">তবে ক্রিকেটারদের এখনই কোভিড-১৯ পরীক্ষা করাবে না বিসিবি। ক্রিকেট বোর্ড ধরে নিচ্ছে, খেলোয়াড়েরা স্বাস্থ্যবিধি ঠিকঠাক মেনেই চলছেন। পরীক্ষা যদি করতেই হয়, সেটি বিশেষজ্ঞদের মতামত নিয়ে করা হবে বলে জানান প্রধান নির্বাহী।</span><br style=\"outline: 0px; font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\"><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">নির্দিষ্ট দিন-তারিখ ঠিক না হলেও বিসিবির পরিকল্পনা শুরুতে ক্রিকেটারদের একক অনুশীলন দিয়ে ক্রিকেটীয় কার্যক্রম শুরু করার। সেটি হলে মিরপুর শেরেবাংলা স্টেডিয়ামের ইনডোর, মূল মাঠ ও একাডেমি মাঠে এক সময়ে তিনজন খেলোয়াড় অনুশীলন করতে পারবেন। পরিস্থিতি বুঝে ধীরে ধীরে অনুশীলনে খেলোয়াড়সংখ্যা বাড়বে। তার আগে বিসিবির মেডিকেল বিভাগ নির্বাচকদের সঙ্গে বসে ঠিক করবে শুরুতে কতজন খেলোয়াড় অনুশীলন শুরু করবেন।</span><br></p>', NULL, '', 'images/1591079508.jpeg', 15, NULL, 5, 0, 1, '2020-08-08 12:03:27', '2020-08-08 12:03:27'),
(20, 5, 1, 3, 7, 1, 'একক অনুশীলন নিয়ে নির্বাচক হাবিবুল বাশার বললেন', '<p><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">একক অনুশীলন নিয়ে নির্বাচক হাবিবুল বাশার বললেন, \'খেলোয়াড়দের একক অনুশীলনের মাধ্যমে ক্রিকেটীয় কার্যক্রম শুরুর ব্যাপারে মেডিকেল বিভাগ, ট্রেনারদের সঙ্গে আমাদের আলাপ-আলোচনা চলছে। তবে এটা এখনো চূড়ান্ত হয়নি। একক অনুশীলন শুরু হলে জাতীয় দলের ক্রিকেটাররাই আপাতত প্রাধান্য পাবে।\'</span><br></p>', NULL, '', NULL, 30, NULL, 5, 0, 1, '2020-08-08 12:03:20', '2020-08-08 12:03:20'),
(21, 5, 1, 3, 1, 1, 'শ্রীলঙ্কা ১৩ জন ক্রিকেটারকে নিয়ে আবাসিক ক্যাম্প শুরু করলেও বিসিবি এখনই সে পথে হাঁটবে না', '<p><span style=\"font-family: Kiron, SolaimanLipi, Arial, Vrinda, FallbackBengaliFont, Helvetica, sans-serif; font-size: 18px; background-color: rgb(240, 240, 237);\">শ্রীলঙ্কা ১৩ জন ক্রিকেটারকে নিয়ে আবাসিক ক্যাম্প শুরু করলেও বিসিবি এখনই সে পথে হাঁটবে না। তবে শ্রীলঙ্কার অভিজ্ঞতা পর্যবেক্ষণ করবে তারা। বিসিবির প্রধান চিকিৎসক দেবাশীষ চৌধুরী বললেন, \'শ্রীলঙ্কার ট্রেনিং ক্যাম্পটা আমরা লক্ষ করছি। ওদেরটা ফলপ্রসূ হলে আমরাও সে অনুযায়ী কিছু নির্দেশনা তৈরি করতে পারব। বোর্ড থেকে আমাদের প্রস্তুতি নিয়ে রাখতে বলা হয়েছে, যেন স্বল্প সময়ের নোটিশে সব শুরু করতে পারি। যেহেতু প্রস্তুতি নিয়ে রাখতে বলা হচ্ছে, ধরে নিচ্ছি, অনুশীলন শুরুর পরিকল্পনাও করা হচ্ছে।\'</span><br></p>', NULL, '', NULL, 10, NULL, 5, 0, 1, '2020-08-08 12:03:12', '2020-08-08 12:03:12'),
(22, 5, 1, 2, 6, 0, 'Woman accuses MP Enamul of deception, forced abortion', '<p><span style=\"color: rgb(18, 18, 18); font-family: Merriweather;\">A woman, claiming to be the wife of Rajshahi-4 (Bagmara) constituency’s member of parliament Enamul Huque, has accused him of deception and forcefully aborting her foetus.</span><br></p>', NULL, '', 'images/1591083058.jpeg', 20, NULL, 5, 0, 0, '2020-08-08 07:52:03', '2020-08-08 01:52:03'),
(23, 5, 1, 2, 8, 0, 'Title update from react 3 Edit checking refresh', '<p>Test update Abc adc abc</p>', NULL, NULL, NULL, 15, NULL, 5, 0, 0, '2020-08-08 07:52:03', '2020-08-08 01:52:03'),
(26, 5, 0, 4, 4, 1, 'Daft Punk - Technologic', '<p>D8K90hX4PrE<br></p>', NULL, '', NULL, 0, NULL, 0, 0, 0, '2020-06-04 03:02:41', '2020-06-04 03:02:41'),
(27, 5, 0, 4, 4, 0, 'Title update from react 3', 'D8K90hX4PrE', NULL, NULL, NULL, 0, NULL, 0, 1, 0, '2020-08-05 06:18:02', '2020-08-05 00:18:02'),
(29, 5, 1, 4, 7, 0, 'Six states report record-breaking increases in new coronavirus cases', 'https://youtu.be/kJx98zxA2cI', NULL, NULL, NULL, 30, NULL, 5, 0, 1, '2020-08-08 12:03:38', '2020-08-08 12:03:38'),
(30, 5, 1, 2, 1, 0, 'Police quizzed bullet-hit Sinha, claims FIR', '<p style=\"margin-bottom: var(--space2); line-height: 1.67;\">Bullet-hit retired major of Bangladesh Army Sinha Mohammad Rashed Khan, during a quizzing, informed police that the license of his firearm was in his room at Nilima Resort, in Cox’s Bazar. Later, the&nbsp;<a target=\"_blank\" href=\"https://en.prothomalo.com/bangladesh/crime-and-law/7-policemen-including-pradip-liakat-suspended-over-sinha-killing\" style=\"\">law enforcement members</a>&nbsp;detained Shipra Debnath and seized local and foreign alcohol and hashish from that room.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">Police said this in the statement of a case filed under narcotics control act against Stamford University student Shipra Debnath with Ramu police station.</p>', 'https://en.prothomalo.com/bangladesh/crime-and-law/police-quizzed-bullet-hit-sinha-claims-fir', NULL, NULL, 30, NULL, 5, 0, 0, '2020-08-08 07:52:03', '2020-08-08 01:52:03'),
(31, 5, 1, 4, 1, 0, 'Nearly 300,000 Coronavirus Deaths Now Predicted In US By End Of Year', '<p>TODAY brings you the latest headlines and expert tips on money, health and parenting. We wake up every morning to give you and your family all you need to start your day. If it matters to you, it matters to us. We are in the people business. Subscribe to our channel for exclusive TODAY archival footage &amp; our original web series.  <br></p>', NULL, 'https://www.youtube.com/watch?v=4Baq3_2PRa4', NULL, 50, NULL, 5, 0, 1, '2020-08-08 07:58:41', '2020-08-08 01:58:41'),
(32, 5, 1, 2, 7, 0, 'Fauci warns COVID-19 vaccine may be only partially effective, public health measures still needed', '<p style=\"margin-bottom: var(--space2); line-height: 1.67;\">An approved coronavirus vaccine could end up being effective only 50-60 per cent of the time, meaning public health measures will still be needed to keep the pandemic under control, Anthony Fauci, the top US infectious diseases expert, said on Friday.</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">\"We don\'t know yet what the efficacy might be. We don\'t know if it will be 50 per cent or 60 per cent. I\'d like it to be 75 per cent or more,\" Fauci said in a webinar hosted by Brown University. \"But the chances of it being 98 per cent effective is not great, which means you must never abandon the public health approach.\"</p><p style=\"margin-bottom: var(--space2); line-height: 1.67;\">The novel coronavirus has infected nearly 5 million people in the United States and killed more than 160,000.</p>', 'https://en.prothomalo.com/international/americas/fauci-warns-covid-19-vaccine-may-be-only-partially-effective-public-health-measures-still-needed', NULL, NULL, 50, NULL, 5, 0, 1, '2020-08-08 08:07:08', '2020-08-08 02:07:08'),
(33, 5, 1, 2, 1, 0, 'Dhaka’s relations with Delhi, Beijing must not be compared: foreign minister', '<p><span style=\"color: rgb(0, 0, 0); font-family: &quot;Droid Serif&quot;, serif;\">Foreign Minister Dr AK Abdul Momen has said Bangladesh\'s relations with India and China should not be compared, adding that Bangladesh emphasises its development through cooperation and collaboration.</span><br></p>', 'https://www.thedailystar.net/dhaka-relations-delhi-beijing-must-not-be-compared-1941673', NULL, NULL, 0, NULL, 0, 0, 0, '2020-08-08 13:42:14', '2020-08-08 13:42:14');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

DROP TABLE IF EXISTS `post_comments`;
CREATE TABLE `post_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `reject_note` text DEFAULT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `is_unread` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `post_id`, `user_id`, `comment`, `status`, `reject_note`, `admin_id`, `is_unread`, `created_at`, `updated_at`) VALUES
(1, 27, 5, 'This is first comment', 1, NULL, 0, 0, '2020-06-04 03:54:52', '2020-06-04 03:54:52'),
(2, 27, 5, 'Hello world', 1, NULL, 0, 0, '2020-06-04 03:59:45', '2020-06-04 03:59:45'),
(3, 27, 5, 'Hello world a', 1, NULL, 0, 0, '2020-06-04 04:00:26', '2020-06-04 04:00:26'),
(5, 27, 5, 'abc', 1, NULL, 0, 0, '2020-06-04 04:09:43', '2020-06-04 04:09:43'),
(6, 27, 5, 'dd', 1, NULL, 0, 0, '2020-06-04 04:43:24', '2020-06-04 04:43:24'),
(7, 27, 5, 'abc', 1, NULL, 0, 0, '2020-06-04 04:45:23', '2020-06-04 04:45:23'),
(8, 27, 5, 'aaaaaaaa', 1, NULL, 0, 0, '2020-06-04 06:14:03', '2020-06-04 06:14:03'),
(9, 27, 5, 'ddddddddddd', 1, NULL, 0, 0, '2020-06-04 06:14:35', '2020-06-04 06:14:35'),
(10, 22, 5, 'Hello World', 1, NULL, 0, 0, '2020-06-06 21:00:47', '2020-06-06 21:00:47'),
(11, 22, 5, 'aa update abc', 1, NULL, 0, 0, '2020-06-07 04:10:55', '2020-06-06 22:10:55'),
(12, 22, 5, 'DDR', 1, NULL, 0, 0, '2020-06-06 22:11:00', '2020-06-06 22:11:00'),
(13, 22, 5, 'dddddddd', 1, NULL, 0, 0, '2020-06-06 22:11:33', '2020-06-06 22:11:33'),
(16, 19, 5, 'ddds--------', 1, NULL, 0, 0, '2020-06-07 04:15:50', '2020-06-06 22:15:27'),
(17, 19, 3, 'rrrrrrr------', 1, NULL, 0, 0, '2020-06-07 04:45:40', '2020-06-06 22:16:59'),
(18, 19, 5, 'aaaaa', 1, NULL, 0, 0, '2020-06-07 04:19:04', '2020-06-06 22:19:04'),
(19, 19, 3, 'PPPPPPP', 1, NULL, 0, 0, '2020-06-07 04:45:37', '2020-06-06 22:19:07');

-- --------------------------------------------------------

--
-- Table structure for table `post_galleries`
--

DROP TABLE IF EXISTS `post_galleries`;
CREATE TABLE `post_galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `image` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
CREATE TABLE `post_likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`id`, `post_id`, `user_id`, `created_at`, `updated_at`) VALUES
(13, 18, 5, '2020-06-03 08:01:14', '2020-06-03 08:01:14'),
(24, 22, 5, '2020-06-06 22:40:53', '2020-06-06 22:40:53'),
(25, 2, 5, '2020-06-06 22:40:58', '2020-06-06 22:40:58'),
(26, 4, 5, '2020-06-06 22:45:21', '2020-06-06 22:45:21');

-- --------------------------------------------------------

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
CREATE TABLE `preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preferences`
--

INSERT INTO `preferences` (`id`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(21, 6, 8, '2020-05-11 12:02:48', '2020-05-11 12:02:48'),
(31, 5, 5, '2020-08-06 03:00:01', '2020-08-06 03:00:01'),
(32, 5, 8, '2020-08-06 03:00:01', '2020-08-06 03:00:01'),
(33, 5, 7, '2020-08-06 03:00:01', '2020-08-06 03:00:01'),
(34, 5, 6, '2020-08-06 03:00:01', '2020-08-06 03:00:01'),
(35, 5, 1, '2020-08-06 03:00:01', '2020-08-06 03:00:01'),
(36, 5, 4, '2020-08-06 03:00:01', '2020-08-06 03:00:01');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `ebook_id` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT 1,
  `review_id` int(11) NOT NULL DEFAULT 0,
  `like` int(11) NOT NULL DEFAULT 0,
  `dislike` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=Pending,1=Approve,2=Reject',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=Pending,1=Active, 2=Block, 3=Reject',
  `type` int(11) NOT NULL DEFAULT 1 COMMENT '1=User, 2=Support, 3=Admin',
  `full_name` varchar(100) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `balance` float(8,2) NOT NULL DEFAULT 0.00,
  `reset_code` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `points`, `status`, `type`, `full_name`, `name`, `contact`, `email`, `password`, `image`, `balance`, `reset_code`, `created_at`, `updated_at`) VALUES
(1, 0, 1, 3, 'Supper Admin', 'Admin', '0155455444', 'admin@gmail.com', '$2y$10$.5AozD2PbhnL9jkNPtsCLeSA1LJeSGsHxROHqAI5oru4AKp0HyOyK', NULL, 0.00, NULL, '2020-08-05 05:08:22', '2020-04-19 01:44:15'),
(3, 0, 1, 1, 'Md Foysal', 'Foysal', '01555545', 'admin@gmail.com', '$2y$10$.5AozD2PbhnL9jkNPtsCLeSA1LJeSGsHxROHqAI5oru4AKp0HyOyK', NULL, 0.00, NULL, '2020-08-08 06:40:56', '2020-08-05 03:41:21'),
(5, 300, 1, 1, 'Md Naim Uddin', 'Naim Uddin', '01746767374', 'naim@gmail.com', '$2y$10$JUsFelq/koPqkO5UCN9FYORpYoXz9jNRZ6B/Yf27.oLzGloMbHJs.', NULL, 0.00, NULL, '2020-08-08 12:04:07', '2020-08-08 12:04:07'),
(6, 0, 1, 1, 'Fahmid Hasan', 'Fahmid Hasan', '01647511395', 'fahmidhasananik@gmail.com', '$2y$10$wZKtCe7PR/Rsveobn9b4J.biXiyMD/IyZWrpnS.ykRfY3L3AXekGK', NULL, 0.00, NULL, '2020-08-05 10:39:21', '2020-05-18 07:49:59'),
(7, 0, 1, 1, 'Mabroor Mahmood', 'Mabroor Mahmood', '966563725362', 'mabroor1975@gmail.com', '$2y$10$IyEAU/uECLOC./ueyTsEwevLCtnsfceseW/9/aQup4I8Ld4oYnfE.', NULL, 0.00, NULL, '2020-05-11 10:43:44', '2020-05-11 10:43:44');

-- --------------------------------------------------------

--
-- Table structure for table `user_infos`
--

DROP TABLE IF EXISTS `user_infos`;
CREATE TABLE `user_infos` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT 0,
  `city_id` int(11) NOT NULL DEFAULT 0,
  `address` text DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_infos`
--

INSERT INTO `user_infos` (`id`, `user_id`, `country_id`, `city_id`, `address`, `dob`, `gender`, `bio`, `created_at`, `updated_at`) VALUES
(1, 2, 0, 0, NULL, '2020-02-14', NULL, NULL, '2020-04-29 01:10:00', '2020-04-29 01:10:00'),
(2, 8, 0, 0, NULL, '2020-04-15', NULL, NULL, '2020-05-31 10:42:20', '2020-04-29 03:59:55'),
(4, 5, 1, 2, 'House 106, Park Road', '2020-04-30', 'Male', 'This is simple', '2020-05-11 12:29:27', '2020-05-11 12:29:27'),
(5, 6, 1, 1, 'Badda, Dhaka 1212', '1994-02-01', 'Male', 'Passionate to work not only with my technical skills but to contribute to the overall development of an organization through my ideas, responsibilities, and leadership.', '2020-05-18 07:57:10', '2020-05-18 07:57:10'),
(6, 7, 0, 0, NULL, '2013-07-01', NULL, NULL, '2020-05-11 10:43:44', '2020-05-11 10:43:44'),
(7, 3, 1, 2, 'House 106, Park Road', '2020-04-30', 'Male', 'This is simple', '2020-05-11 12:29:27', '2020-05-11 12:29:27');

-- --------------------------------------------------------

--
-- Table structure for table `work_exps`
--

DROP TABLE IF EXISTS `work_exps`;
CREATE TABLE `work_exps` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Present, 2=Past',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `work_exps`
--

INSERT INTO `work_exps` (`id`, `user_id`, `job_title`, `company`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 5, 'Software Engineer', 'Aranee Limited', '2020-04-29', '2020-05-20', 2, '2020-05-04 05:14:39', '2020-05-03 23:14:39'),
(2, 6, 'Business Development Executive', 'Beatnik Technology Limited', '2020-05-12', NULL, 2, '2020-05-18 07:53:24', '2020-05-18 07:53:24'),
(3, 3, 'Software Engineer', 'Aranee Limited', '2020-04-29', '2020-05-20', 2, '2020-05-04 05:14:39', '2020-05-03 23:14:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_audiences`
--
ALTER TABLE `ad_audiences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_budgets`
--
ALTER TABLE `ad_budgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audience_selects`
--
ALTER TABLE `audience_selects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classifieds`
--
ALTER TABLE `classifieds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classified_galleries`
--
ALTER TABLE `classified_galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ebooks`
--
ALTER TABLE `ebooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ebook_likes`
--
ALTER TABLE `ebook_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edu_infos`
--
ALTER TABLE `edu_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdt_cats`
--
ALTER TABLE `pdt_cats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_galleries`
--
ALTER TABLE `post_galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `preferences`
--
ALTER TABLE `preferences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_infos`
--
ALTER TABLE `user_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_exps`
--
ALTER TABLE `work_exps`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ad_audiences`
--
ALTER TABLE `ad_audiences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ad_budgets`
--
ALTER TABLE `ad_budgets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `audience_selects`
--
ALTER TABLE `audience_selects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `classifieds`
--
ALTER TABLE `classifieds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `classified_galleries`
--
ALTER TABLE `classified_galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ebooks`
--
ALTER TABLE `ebooks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ebook_likes`
--
ALTER TABLE `ebook_likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `edu_infos`
--
ALTER TABLE `edu_infos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pdt_cats`
--
ALTER TABLE `pdt_cats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `post_galleries`
--
ALTER TABLE `post_galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `preferences`
--
ALTER TABLE `preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_infos`
--
ALTER TABLE `user_infos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `work_exps`
--
ALTER TABLE `work_exps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
